package create;

import java.io.FileInputStream;
import java.io.IOException;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;

public class bigDataScore {

	public static void insert(String combo, String txt) {
		try {
			Class.forName("com.mysql.cj.jdbc.Driver");
			Connection con = DriverManager.getConnection("jdbc:mysql://localhost:3305/bigdata11", "root",
					"root@123");
			con.setAutoCommit(false);
			PreparedStatement pstm = null;
			FileInputStream input = new FileInputStream(txt);
			@SuppressWarnings("unused")
			String fs = input.toString();
			@SuppressWarnings("resource")
			XSSFWorkbook wb = new XSSFWorkbook(new FileInputStream(txt));
			XSSFSheet sheet = wb.getSheetAt(0);
			Row row;
			for (int i = 1; i <= sheet.getLastRowNum(); i++) {
				row = sheet.getRow(i);

				int Roll_No = (int) row.getCell(0).getNumericCellValue();
				int Week1_SH1 = (int) row.getCell(1).getNumericCellValue();
				int Week1_SH2 = (int) row.getCell(2).getNumericCellValue();
				int Week2_SH1 = (int) row.getCell(3).getNumericCellValue();
				int Week2_SH2 = (int) row.getCell(4).getNumericCellValue();
				int Week3_SH1_2 = (int) row.getCell(5).getNumericCellValue();
				int Week4_SH1_2 = (int) row.getCell(6).getNumericCellValue();
				int Week5_SH1 = (int) row.getCell(7).getNumericCellValue();
				double Week5_SH2 = (double) row.getCell(8).getNumericCellValue();
				double Week6_SH1 = (double) row.getCell(9).getNumericCellValue();
				double Week6_SH2 = (double) row.getCell(10).getNumericCellValue();
				int Week1_ENB = (int) row.getCell(11).getNumericCellValue();
				int Week2_ENB = (int) row.getCell(12).getNumericCellValue();
				int Week3_ENB = (int) row.getCell(13).getNumericCellValue();
				int Week4_ENB = (int) row.getCell(14).getNumericCellValue();
				int Week5_ENB = (int) row.getCell(15).getNumericCellValue();
				int Week6_ENB = (int) row.getCell(16).getNumericCellValue();
				double Total = (double) row.getCell(17).getNumericCellValue();

				String sql = "INSERT INTO bigdata_score(Roll_No," + "Week1_SH1," + "Week1_SH2," + "Week2_SH1,"
						+ "Week2_SH2," + "Week3_SH1_2," + "Week4_SH1_2," + "Week5_SH1," + "Week5_SH2," + "Week6_SH1,"
						+ "Week6_SH2," + "Week1_ENB," + "Week2_ENB," + "Week3_ENB," + "Week4_ENB," + "Week5_ENB,"
						+ "Week6_ENB, Total) VALUES('" + Roll_No + "','" + Week1_SH1 + "','" + Week1_SH2
						+ "','" + Week2_SH1 + "','" + Week2_SH2 + "','" + Week3_SH1_2 + "','" + Week4_SH1_2 + "','"
						+ Week5_SH1 + "','" + Week5_SH2 + "','" + Week6_SH1 + "','" + Week6_SH2 + "','" + Week1_ENB
						+ "','" + Week2_ENB + "','" + Week3_ENB + "','" + Week4_ENB + "','" + Week5_ENB + "','"
						+ Week6_ENB + "','" + Total + "')";
				pstm = (PreparedStatement) con.prepareStatement(sql);
				pstm.execute();
				System.out.println("Import rows " + i);
			}
			con.commit();
			pstm.close();
			con.close();
			input.close();
			System.out.println("Success import excel to mysql table");
		} catch (ClassNotFoundException e) {
			System.out.println(e);
		} catch (SQLException ex) {
			System.out.println(ex);
		} catch (IOException ioe) {
			System.out.println(ioe);
		}

	}
}