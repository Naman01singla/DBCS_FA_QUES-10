package mainScreen;

import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.geometry.Pos;
import javafx.scene.control.Button;
import javafx.scene.control.ComboBox;
import javafx.scene.control.Label;
import javafx.scene.control.TextField;
import javafx.scene.layout.Pane;
import javafx.scene.text.Font;
import javafx.scene.text.FontWeight;
import javafx.stage.Window;

public class StudentRegistration {

	Label lbl_Student = new Label("Student Registration");
	Label lbl_regno = new Label("Regestration Number:");
	Label lbl_rollno = new Label("Roll Number:");
	Label lbl_name = new Label("Name:");
	Label lbl_fname = new Label("Father Name:");
	Label lbl_mname = new Label("Mother Name:");
	Label lbl_course = new Label("Course:");
	Label lbl_sem = new Label("Semester:");
	Label lbl_year = new Label("Year:");

	private TextField txt_browse = new TextField();
	private TextField txt_regno = new TextField();
	private TextField txt_rollno = new TextField();
	private TextField txt_name = new TextField();
	private TextField txt_fname = new TextField();
	private TextField txt_mname = new TextField();

	private ComboBox<String> course = new ComboBox<String>();
	private ComboBox<String> sem = new ComboBox<String>();
	private ComboBox<String> year = new ComboBox<String>();

	ObservableList<String> courselist = FXCollections.observableArrayList();
	ObservableList<String> semlist = FXCollections.observableArrayList();
	ObservableList<String> yearlist = FXCollections.observableArrayList();

	private Button btn_browse = new Button("Browse");
	
	private Button btn_delete = new Button("Delete");
	
	private Button btn_modify = new Button("Modify");
	
	private Button btn_insert = new Button("Insert Data");
	
	private Button btn_view = new Button("View PDF");
	
	public StudentRegistration(Pane thePane) {
		courselist.addAll("Stats", "DBCS", "BigData", "Network", "PMF");
		semlist.addAll("1", "2", "3", "4", "5", "6", "7", "8");
		yearlist.addAll("1", "2", "3", "4");

		setupLabelUI(lbl_Student, "Arial", 30, 50, Pos.BASELINE_CENTER, 80, 20);
		lbl_Student.setFont(Font.font("Arial", FontWeight.BOLD, 30));

		setupButtonUI(btn_browse, "Arial", 19, 50, Pos.BASELINE_CENTER, 350, 175);
		 
		setupTextUI(txt_browse, "Arial", 19, 250, 150, Pos.BASELINE_LEFT, 200, 175, true);
				
		course.setItems(courselist);
		sem.setItems(semlist);
		year.setItems(yearlist);

		thePane.getChildren().addAll(txt_rollno, txt_mname, txt_fname, txt_name, txt_regno, course, sem, year,
				txt_browse, lbl_Student, lbl_regno, lbl_rollno, lbl_name, lbl_fname, lbl_mname, lbl_course, lbl_sem,
				lbl_year);
	}
	
	private void setupTextUI(TextField t, String ff, double f, double w, double d, Pos p, double x, double y,
			boolean e) {
		t.setFont(Font.font(ff, f));
		t.setMinWidth(w);
		t.setMaxWidth(w);
		t.setAlignment(p);
		t.setLayoutX(x);
		t.setLayoutY(y);
		t.setEditable(e);
	}
	
	private void setupLabelUI(Label l, String ff, double f, double w, Pos p, double x, double y) {
		l.setFont(Font.font(ff, f));
		l.setMinWidth(w);
		l.setAlignment(p);
		l.setLayoutX(x);
		l.setLayoutY(y);
	}

	private void setupButtonUI(Button b, String ff, double f, double w, Pos p, double x, double y) {
		b.setFont(Font.font(ff, f));
		b.setMinWidth(w);
		b.setAlignment(p);
		b.setLayoutX(x);
		b.setLayoutY(y);
	}

}
